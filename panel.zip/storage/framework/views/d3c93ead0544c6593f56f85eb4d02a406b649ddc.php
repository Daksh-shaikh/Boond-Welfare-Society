<?php $__env->startSection('main-container'); ?>
<!-- PAGE CONTENT WRAPPER -->
<div class="page-content-wrap">

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="form-group">


                        <form action="<?php echo e(route('member.amount')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="col-md-2">
                                <input type="number" placeholder="Enter Amount" class="form-control" name="amount"
                                    value="<?php echo e(old('amount',session('createdAmount'))); ?>">
                                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <button
                                style="margin-left: 30px; background-color: #00cc00; border: #00cc00; color: white; padding: 8px; margin-top: 0px; border-radius: 5px; font-size: 13px;">
                                Update Membership Amount</button>

                        </form>


                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="row">
        <div class="col-md-12" style="margin-top:-17px;">
            <div class="panel panel-default">
                <!-- START DEFAULT DATATABLE -->
                <div class="panel panel-default">


                    <div class="col-md-2"></div>

                    <h5 class="panel-title"
                        style="margin-bottom: -5px; color:#FFFFFF; background-color:#006699; width:100%; font-size:14px;"
                        align="center"><i class="fa fa-money">
                        </i> &nbsp;Member Registration</h5>
                </div>



                <div class="col-md-2"></div>






            </div>



            <!-- END DEFAULT DATATABLE -->


            <div class="row">


<form action="/memberRegistrationDeleteMultiple" method="POST">
    <?php echo csrf_field(); ?>
                <div class="panel panel-default">

                    
                    <button class="btn btn-danger" style="margin-left: 25px; margin-top: 15px;" type="submit" name="delete_multiple">
                        <i class="fa fa-trash-o"></i>Delete Multiple
                    </button>
                    


                    <div class="panel-body">
                        <table class="table datatable">
                            <thead>
                                <tr>
                                    <!-- <th></th> -->
                                    <th>Sr.no.</th>
                                    <th>Full Name</th>
                                    <th>Gender</th>
                                    <th>Age</th>
                                    <th>Email</th>
                                    <th>Mobile No.</th>

                                    <th>City</th>
                                    <th>Address</th>
                                    <th>Pincode</th>
                                    <th>Amount</th>
                                    <th>Payment Status</th>
                                    <th>image</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($MemberRegistration)>0): ?>
                                <?php $__currentLoopData = $MemberRegistration; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $memberRegistration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <!-- <td><input type="checkbox" name="ids[]" value="3"></td> -->
                                    <div style="display:flex;">
                                        <td>
                                            <input type="checkbox" name="ids[<?php echo e($memberRegistration->id); ?>]" value="<?php echo e($memberRegistration->id); ?>">
                                            &nbsp; <?php echo e($loop->index+1); ?>

                                           </td>
                                    </div>
                                    <td><?php echo e($memberRegistration->name); ?></td>
                                    <td><?php echo e($memberRegistration->gender); ?></td>
                                    <td><?php echo e($memberRegistration->age); ?></td>
                                    <td><?php echo e($memberRegistration->email); ?></td>
                                    <td><?php echo e($memberRegistration->mobilenumber); ?></td>
                                    <td><?php echo e($memberRegistration->city); ?></td>
                                    <td><?php echo e($memberRegistration->address); ?></td>
                                    <td><?php echo e($memberRegistration->pincode); ?></td>
                                    <td><?php echo e($memberRegistration->amount); ?></td>
                                    <td><?php echo e($memberRegistration->payment_status); ?></td>
                                    <td>

                                        <a href="#" onclick="previewImage('<?php echo e(asset('products/' . $memberRegistration->image)); ?>')">PREVIEW</a>
                                    </td>

                                    <!-- JavaScript function for previewing the image -->




                                    <td>
                                        <div style="display:flex;">
                                              <a href="<?php echo e(route('reg.edit',$memberRegistration->id)); ?>">
                                                    <button  style="background-color:#0066cc; border:none; max-height:25px; margin-right:3px;" type="button" class="btn btn-info" data-toggle="tooltip" data-placement="top" title="Edit "><i class="fa fa-edit" style="margin-left:5px;"></i></button></a>


                                                 <a href="<?php echo e(route('store.destroyMemberRegistration', $memberRegistration->id)); ?>">
                                                    <button style="background-color:#ff0000; border:none; max-height:25px;" type="button" class="btn btn-info" data-toggle="tooltip" data-placement="top" title="Delete">
                                                        <i class="fa fa-trash-o" style="margin-left:5px;"></i>
                                                    </button>
                                                </a>


                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr>
                                <td colspan="3">User Not Found</td>
                            </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>




                </div>
</form>






            </div>
            <!-- PAGE CONTENT WRAPPER -->
        </div>
        <!-- END PAGE CONTENT -->
    </div>
    <!-- END PAGE CONTAINER -->


        <script>
            function previewImage(imageUrl) {
                // Open a new window or modal to display the image
                window.open(imageUrl, 'Image Preview', 'width=800, height=600');
                // Alternatively, you can use a modal library like Bootstrap modal
                // to display the image within the current page.
            }
        </script>


        <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel_projects\admin_panel\resources\views/frontend/member_registration.blade.php ENDPATH**/ ?>
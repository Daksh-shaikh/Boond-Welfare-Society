<?php $__env->startSection('main-container'); ?>
<!-- PAGE CONTENT WRAPPER -->


<div class="page-content-wrap">

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="form-group">


                        <form action="<?php echo e(route('reg.edit', [$regedit->id])); ?>" method="post">
                            <?php echo csrf_field(); ?>


                        </form>


                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="row">
        <div class="col-md-12" style="margin-top:-17px;">
            <div class="panel panel-default">
                <!-- START DEFAULT DATATABLE -->
                <div class="panel panel-default">


                    <div class="col-md-2"></div>

                    <h5 class="panel-title"
                        style="margin-bottom: -5px; color:#FFFFFF; background-color:#006699; width:100%; font-size:14px;"
                        align="center"><i class="fa fa-money">
                        </i> &nbsp;Edit Member Registration</h5>
                </div>


                


                    <div class="row">
                        <div class="col-md-12" >

                            <div class="panel panel-default">

                                <div class="col-md-2"></div>

                                <div class="panel-body" style="margin-top:-10px; margin-bottom:-5px;">
                                    <div class="form-group">
                                        <form action="<?php echo e(route('reg.update', [$regedit->id])); ?>" method="post">
                                            <?php echo csrf_field(); ?>


                                            <input type="hidden" name="id" value="<?php echo e($regedit->id); ?>">


                                            <div class="col-md-12">
                                                <div class="form-group" >
                                                    <!-- <div class="col-md-3"></div> -->
                                                    <div class="col-md-6" style="margin-top:15px;">
                                                        <label style="font-weight: bold;">Full Name<font color="#FF0000">*</font></label>
                                                        <input type="text" name="name" placeholder="ceqocu@mailinator.com" class="form-control" value="<?php echo e(old('name', $regedit->name)); ?>" required/>

                                                        <?php if($errors->has('name')): ?>
                                                            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                                        <?php endif; ?>
                                                    </div>

                                                    <div class="col-md-6" style="margin-top:15px;">
                                                        <label style="font-weight: bold;">Gender<font color="#FF0000" >*</font></label>
                                                        <select name="gender" class="form-control" value="<?php echo e($regedit->gender); ?>">
                                                            
                                                            <option value="Select" <?php echo e($regedit->gender === 'Select' ? 'selected' : ''); ?>>Select</option>
                                                            <option value="Female" <?php echo e($regedit->gender === 'Female' ? 'selected' : ''); ?>>Female</option>
                                                            <option value="Male" <?php echo e($regedit->gender === 'Male' ? 'selected' : ''); ?>>Male</option>

                                                        </select>
                                                    </div>


                                                    <div class="col-md-6" style="margin-top:15px; ">
                                                        <label style="font-weight: bold;">Age<font color="#FF0000">*</font></label>
                                                        <input type="number" name="age" placeholder="50" class="form-control" value="<?php echo e($regedit->age); ?>" required />
                                                        <?php if($errors->has('age')): ?>
                                                        <span class="text-danger"><?php echo e($errors->first('age')); ?></span>
                                                    <?php endif; ?>
                                                    </div>
                                                    <div class="col-md-6" style="margin-top:15px;">
                                                        <label style="font-weight: bold;">Email<font color="#FF0000">*</font></label>
                                                        <input type="email" name="email" placeholder="kahufa@mailinator.com" class="form-control" value="<?php echo e($regedit->email); ?>" required/>
                                                        <?php if($errors->has('email')): ?>
                                                        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                                    <?php endif; ?>
                                                    </div>

                                                    <div class="col-md-6" style="margin-top:15px;">
                                                        <label style="font-weight: bold;">Mobile No<font color="#FF0000">*</font></label>
                                                        <input type="number" name="mobilenumber" placeholder="1234567890" class="form-control" value="<?php echo e($regedit->mobilenumber); ?>" required/>
                                                        <?php if($errors->has('mobilenumber')): ?>
                                                        <span class="text-danger"><?php echo e($errors->first('mobilenumber')); ?></span>
                                                    <?php endif; ?>
                                                    </div>
                                                    <div class="col-md-6" style="margin-top:15px;">
                                                        <label style="font-weight: bold;">City<font color="#FF0000">*</font></label>
                                                        <input type="text" name="city" placeholder="widabunic@mailinator.com" class="form-control" value="<?php echo e($regedit->city); ?>" required/>
                                                        <?php if($errors->has('city')): ?>
                                                        <span class="text-danger"><?php echo e($errors->first('city')); ?></span>
                                                    <?php endif; ?>
                                                    </div>


                                                    <div class="col-md-6" style="margin-top:15px;">
                                                        <label style="font-weight: bold;">Address<font color="#FF0000">*</font></label>
                                                        <input type="text" name="address" placeholder="bucilezume@mailinator.com" class="form-control" value="<?php echo e($regedit->address); ?>" required/>
                                                        <?php if($errors->has('address')): ?>
                                                        <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                                                    <?php endif; ?>
                                                    </div>
                                                    <div class="col-md-6" style="margin-top:15px;">
                                                        <label style="font-weight: bold;">Pincode<font color="#FF0000">*</font></label>
                                                        <input type="number" name="pincode" placeholder="869" class="form-control" value="<?php echo e($regedit->pincode); ?>" required/>
                                                        <?php if($errors->has('pincode')): ?>
                                                        <span class="text-danger"><?php echo e($errors->first('pincode')); ?></span>
                                                    <?php endif; ?>
                                                    </div>
                                                    


                                                    <div class="col-md-2" style="margin-top:2vh;">

                                                        <div class="input-group" style=" margin-bottom:15px;">

                                                            <button style="background-color:#00cc00; border:none; max-height:35px; "  type="submit" class="btn btn-info" data-toggle="tooltip" data-placement="top" data-original-title="" title=""><i class="fa fa-plus" style="margin-left:5px;"></i>Update</button>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                </div>
                <div class="col-md-2"></div>






            </div>



            <!-- END DEFAULT DATATABLE -->


            <div class="row">


            </div>
            <!-- PAGE CONTENT WRAPPER -->
        </div>
        <!-- END PAGE CONTENT -->
    </div>
    <!-- END PAGE CONTAINER -->


        <script>
            function previewImage(imageUrl) {
                // Open a new window or modal to display the image
                window.open(imageUrl, 'Image Preview', 'width=800, height=600');
                // Alternatively, you can use a modal library like Bootstrap modal
                // to display the image within the current page.
            }
        </script>


        <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel_projects\admin_panel\resources\views/frontend/member_registrationEdit.blade.php ENDPATH**/ ?>